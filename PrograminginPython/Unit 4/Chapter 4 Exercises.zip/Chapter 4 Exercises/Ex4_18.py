# -*- coding: utf-8 -*-
"""
Created on Thu Oct 21 01:27:25 2021

@author: Tim
"""

for y in range(1, 11):
    for x in range(1, 11):
        print("%4d" % (y * x), end="")
    print()
    