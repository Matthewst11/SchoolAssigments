# -*- coding: utf-8 -*-
"""
Created on Thu Oct 21 01:02:36 2021

@author: Tim
"""

inputStr = input("Enter a string: ")

for ch in inputStr:
    if ch >= "A" and ch <= "Z":
        print(ch)
