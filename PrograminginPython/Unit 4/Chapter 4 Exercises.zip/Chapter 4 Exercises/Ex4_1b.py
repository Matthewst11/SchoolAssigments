# -*- coding: utf-8 -*-
"""
Created on Thu Oct 21 00:02:03 2021

@author: Tim
"""

total = 0
for i in range(1, 101):
    total = total + i * i #Or i**

print("The sum of all squares between 1 and 100 is", total)