# -*- coding: utf-8 -*-
"""
Created on Thu Oct 21 00:06:16 2021

@author: Tim
"""

for i in range(0, 21):
    print("2**", i, " is ", 2**i)
    