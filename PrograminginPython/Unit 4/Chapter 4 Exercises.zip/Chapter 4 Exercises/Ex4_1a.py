# -*- coding: utf-8 -*-
"""
Created on Wed Oct 20 23:52:25 2021

@author: Tim
"""

total = 0
for i in range(2, 101, 2):
    total = total + i
    
print("The total of the even number from 2 to 100 is", total)